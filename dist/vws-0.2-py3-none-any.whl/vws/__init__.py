def main():
    return 0